const { app, BrowserWindow, Menu } = require('electron');

function createWindow() {
    const win = new BrowserWindow({
        width: 800,
        height: 600,
        webPreferences: {
            nodeIntegration: true
        }
    });

    win.loadURL('http://localhost:5173'); // Carga la aplicación React

    // Crea un menú vacío
    const menu = Menu.buildFromTemplate([]);
    
    // Establece el menú vacío como la barra de menú de la aplicación
    Menu.setApplicationMenu(menu);
}

app.whenReady().then(createWindow);
