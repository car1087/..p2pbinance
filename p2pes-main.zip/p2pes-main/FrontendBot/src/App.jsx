    import './App.css';
    import { useEffect, useState } from 'react';
    import axios from 'axios';


    function App() {
        const URLSOCKET = "ws://localhost:4030";
        const [data, setData] = useState(null);
        const [mode,setMode]=useState("")
        const [montoTotalUSDT, setMontoTotalUSDT] = useState(null); // Nuevo estado para almacenar el monto total en USDT

        const handleChangeMode = () => {
            const nuevoModo = mode === 'compra' ? 'venta' : 'compra';
            axios.post('http://localhost:4030/ChangeMode', { Mode: nuevoModo })
                .then(response => {
                    console.log(response.data);
                    setMode(nuevoModo); // Actualiza el estado del modo
                })
                .catch(error => {
                    console.error('Error al cambiar el modo:', error);
                });
        };


        useEffect(() => {
            const socket = new WebSocket(URLSOCKET);

            socket.onmessage = (event) => {
                const response = JSON.parse(event.data);
                if (response.name === "p2pestdata") {
                    setData(response.data);
                }
            };

            return () => {
                socket.close();
            };
        }, []);

        useEffect(() => {
            const getModoActual = async () => {
                try {
                    const response =await axios.get('http://localhost:4030/GetMode');
                    setMode(response.data.mode)
                } catch (error) {
                    console.error('Error al cambiar el modo a "compra":', error);
                }
            };
            getModoActual();
        }, []);

        // Obtener el usuario de data.Lista que coincida con NOMBRE_DE_USUARIO_P2P
        let miAnuncio = '-Esperando Anuncio';
        if (data && data.Lista) {
            const miUsuario = data.Lista.find(item => item.user === data.NOMBRE_DE_USUARIO_P2P);
            if (miUsuario) {
                miAnuncio = (
                    <div className='fund2'>
                        <p>Usuario: {miUsuario.user}</p>
                        <p>Precio: {miUsuario.precio}</p>
                        <p>Porcentaje: {miUsuario.percent}%</p>
                    </div>
                );
            }
        }



        useEffect(() => {
            // Calcular el monto total en USDT cuando los datos necesarios estén disponibles
            if (data && data.PrecioSugerido && data.FundBalances.BRL) {
                const montoTotal = (data.FundBalances.BRL / data.PrecioSugerido).toFixed(2);
                setMontoTotalUSDT(montoTotal);
            }
        }, [data, mode]); // Se vuelve a calcular cuando cambia data o mode

        


    
        return (
            <div className='contain'>
                {data && !data.Charging && (
                    <div className='datacontain'>
                    {mode==="compra"&&<button onClick={handleChangeMode} className='c'>Cambiar a Venta</button>}
                    {mode==="venta"&&<button onClick={handleChangeMode} className='b'>Cambiar a Compra</button>}

                        <div className='containfunds'>     <div className='funds'>
                                <h3>Balance Total </h3>
                            
                                <p>USDT: {data.BalanceActual}</p>
                            </div>  <div className='funds'>
                                <h3>FUND-Balances</h3>
                                <p>BRZ: {data.FundBalances.BRZ}</p>
                                <p>BRL: {data.FundBalances.BRL}</p>
                                <p>USDT: {data.FundBalances.USDT}</p>
                            </div>

                            <div className='funds'>
                                <h3>Spot-Balances</h3>
                                <p>BRZ: {data.SpotBalances.BRZ}</p>
                                <p>USDT: {data.SpotBalances.USDT}</p>
                            </div>

                        

                            
                    
                        </div>

                        <div className='containfunds'>
                            <div className='funds'>
                                <h3>Mi anuncio</h3>
                                {miAnuncio}
                            </div>
                            <div className='funds'>
                                <h3>Acción Requerida</h3>
                                <p>{data.AccionRequerida || '-'}</p>
                                <h3>Acción Actual</h3>
                                <p>{data.AccionActual || '-'}</p>
                            </div>


                            <div className='funds'>
                                <h3>Precios Mercado</h3>
                                <p>Compra: {data.Precios.compra}</p>
                                <p>Venta: {data.Precios.venta}</p>
                                <h3>Precio Sugerido</h3>
                                <p>{isNaN(data.PrecioSugerido) ? 'Cargando' : data.PrecioSugerido}</p>
                                {mode === "venta" &&
                                <div>
                                <h3>Monto USDT a Vender </h3>
                                <p>{isNaN(montoTotalUSDT) ? 'Cargando' : montoTotalUSDT}</p> </div>
}


                            </div>




                        </div>

                        <div className='users'>
        {data.Lista
            .slice(0, 3) // Limita la lista a los primeros 3 elementos
            .sort((a, b) => mode === "venta" ? b.precio - a.precio : a.precio - b.precio) // Ordena la lista según el modo
            .map((item, index) => (
                <div key={index} className="card">
                    <h4>Usuario: {item.user}</h4>
                    <p>Precio: {item.precio}</p>
                    <p>Porcentaje: {item.percent}%</p>
                </div>
            ))}
    </div>


                        <div className='ganancias'>
                                <h3>Ganancias</h3>
                                <p>Total: {data.ganancias}</p>
                                {mode==="compra" && <p>Estimada USDT : {data.GananciaPorVentaTotal ||"Cargando"}</p>} 
                                {mode==="venta" && <p>Estimada BRL: {data.GananciaPorVentaTotal ||"Cargando"}</p>} 
                            </div>


            

                    
                    </div>
                )}
                {data && data.Charging && <div><h3>Cargando</h3></div>}
            </div>
        );
    }

    export default App;
