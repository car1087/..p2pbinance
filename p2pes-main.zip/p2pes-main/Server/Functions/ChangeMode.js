const fs = require('fs');
const path = require('path');

function actualizarModo(req, res) {
    const { Mode } = req.body;

    if (!Mode || (Mode !== 'venta' && Mode !== 'compra')) {
        return res.status(400).json({ error: 'Modo no válido. Debe ser "venta" o "compra".' });
    }

    const modeFilePath = path.join(__dirname, 'mode.json');

    fs.readFile(modeFilePath, (err, data) => {
        let modeData = { mode: Mode };
        if (!err) {
            modeData = JSON.parse(data);
            modeData.mode = Mode;
        }

        fs.writeFile(modeFilePath, JSON.stringify(modeData), (err) => {
            if (err) {
                return res.status(500).json({ error: 'Error al actualizar el modo.' });
            }
            res.json({ mode: modeData.mode });
        });
    });
}

module.exports = {
    actualizarModo
};
