const  copiarNumeroPrecio=async(numero)=>{
    return new Promise((resolve, reject) => {
        // Utilizar importación dinámica para cargar el módulo clipboardy
        import('clipboardy').then(module => {
            const clipboardy = module.default;

            // Copiar el número al portapapeles
            clipboardy.write(numero.toString());
            console.log("new Price-copied   "+numero)
            resolve(numero);
        }).catch(error => {
            console.error("Error al cargar el módulo clipboardy:", error);
            reject(error);
        });
    });
}

// Llamar a la función con el número que deseas copiar


module.exports=copiarNumeroPrecio