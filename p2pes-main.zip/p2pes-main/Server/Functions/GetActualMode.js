const fs = require('fs');
const path = require('path');

function getActualMode(req, res) {
    const modeFilePath = path.join(__dirname, 'mode.json');
    
    // Lee el contenido del archivo modo.json
    const data = fs.readFileSync(modeFilePath);

    const modo = JSON.parse(data).mode;
    
    res.json({ mode: modo });

}

module.exports = {
    getActualMode
};
