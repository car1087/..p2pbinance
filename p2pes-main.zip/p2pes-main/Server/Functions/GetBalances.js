const { RestClientV5 } = require('bybit-api');

const dotenv = require('dotenv');
dotenv.config();
const apiKey = process.env.API_KEY;
const secret = process.env.SECRET;
const memberId = process.env.Memberid;


let Balances

async function obtenerBalance(accountType, monedas) {
    const client = new RestClientV5({
        key: apiKey,
        secret: secret,
    });

        try {
            // Obtener todos los balances de la cuenta
            const balanceResult = await client.getAllCoinsBalance({
                memberId: memberId,
                accountType: accountType,
            });

            // Crear un objeto para los balances solicitados
            const balances = {};

            // Iterar a través de los resultados y llenar el objeto con los balances solicitados
            for (const balance of balanceResult.result.balance) {
                if (monedas.includes(balance.coin)) {
                    // Añadir el balance de la moneda al objeto balances
                    balances[balance.coin] = parseFloat(balance.transferBalance);
                }
            }
            Balances= balances;

            return Balances

        } catch (e) {
            console.error(`Error al obtener el balance:`, e);

            // Reintentar después de 10 segundos
        }
    
}
const Init = async () => {
    const monedas = ['USDT', 'BRZ', 'BRL'];
    await obtenerBalance('FUND', monedas);
};



Init();



module.exports = obtenerBalance