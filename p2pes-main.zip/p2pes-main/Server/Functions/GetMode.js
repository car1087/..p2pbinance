const fs = require('fs');
const path = require('path');

const leerModo=async()=> {
    const modeFilePath = path.join(__dirname, 'mode.json');

    try {
        // Lee el contenido del archivo modo.json
        const data = fs.readFileSync(modeFilePath);
        // Parsea el contenido como JSON y lo retorna
        return JSON.parse(data).mode;

     

    } catch (error) {
        // Si hay un error al leer el archivo, retorna null
        console.error('Error al leer el modo:', error);
        return null;
    }
}

leerModo()

module.exports = {
    leerModo
};
