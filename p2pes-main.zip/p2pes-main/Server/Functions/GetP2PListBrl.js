
const Navegador = require("./NavegadorPW");
const cheerio = require('cheerio');
const {leerModo} = require ("./GetMode")
let list = [];

const w = (ms) => new Promise(resolve => setTimeout(resolve, ms));


const P2PLIST = async () => {
    try {
        await w(5000)

        const browser = await Navegador();
        const page = await browser.newPage();
                console.log("cargando lista")
                await page.goto('https://www.bybit.com/fiat/trade/otc/?actionType=1&token=USDT&fiat=BRL&paymentMethod=');
                await w(20000)

                console.clear()
        
        while (true) {
            try {

                // Obtener el contenido HTML de la página
                const html = await page.content();

                // Cargar el HTML en Cheerio
                const $ = cheerio.load(html);

                // Seleccionar todas las filas de la tabla
                const filas = $('tbody.trade-table__tbody tr');

                // Crear un array para almacenar los datos extraídos
                let datosP2P = [];

                // Iterar sobre cada fila y extraer los datos
                filas.each((index, fila) => {
                    // Extraer los datos de la fila
                    const user = $(fila).find('td:nth-child(1) > div > div:nth-child(2) > div > div:nth-child(1) > div > div:nth-child(1) > div > span').text().trim();
                    const precio = $(fila).find('td:nth-child(2) > div > div:nth-child(1) > span').text().trim();
                    const payment = $(fila).find('td:nth-child(4) > div > div > div > div > div').text().trim();
                    const percentText = $(fila).find('td:nth-child(1) > div > div:nth-child(2) > div > div:nth-child(2) > div > span.execute-rate').text().trim();
                    const percent = parseFloat(percentText.replace('%', ''));
                    const monto = $(fila).find('td:nth-child(3) > div > div:nth-child(2) > div > div:nth-child(1) > div').text().trim();
                    const montoNumerico = parseFloat(monto.split(' ')[0]);

                    const datos = {
                        user,
                        precio,
                        percent,
                        payment,
                        montoNumerico
                    };
                    
                    // Añadir el objeto al array de datos
                    datosP2P.push(datos);
                });


                datosP2P = datosP2P.filter(dato => dato.payment.includes('BRL Balance') );
                
            
                                // Ordenar datosP2P por precio de menor a mayor
                datosP2P.sort((a, b) => parseFloat(a.precio) - parseFloat(b.precio));


                const mode= await leerModo()
                // Verificar si el primer elemento tiene un precio mayor al segundo
                if (mode ==="compra"&&datosP2P.length > 1 && parseFloat(datosP2P[0].precio) > parseFloat(datosP2P[1].precio)) {
                    // Eliminar el primer elemento de la lista si rompe con la lógica de ordenamiento
                    datosP2P.shift();
                }

                if (mode ==="venta"&&datosP2P.length > 1 && parseFloat(datosP2P[0].precio) < parseFloat(datosP2P[1].precio)) {
                    // Eliminar el primer elemento de la lista si rompe con la lógica de ordenamiento
                    datosP2P.shift();
                }

                


                // Actualizar la lista global con los datos filtrados y ordenados
                list = datosP2P.length > 0 ? datosP2P : [];


                await new Promise(resolve => setTimeout(resolve, 2000));

            } catch (error) {
                console.error("Error while scraping:", error);
        
                
                await new Promise(resolve => setTimeout(resolve, 3000));
            }
        }
    } catch (error) {
        console.error('Error durante la navegación:', error);
        await new Promise(resolve => setTimeout(resolve, 10000));

    }
};

const List = async () => {
    return list;
};

P2PLIST()
// Ejecutar la función
module.exports = {
    P2PLIST,
    List
};
