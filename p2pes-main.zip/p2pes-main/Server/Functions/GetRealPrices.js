const puppeteer = require('puppeteer-extra');
const StealthPlugin = require('puppeteer-extra-plugin-stealth');
puppeteer.use(StealthPlugin());
const Navegador = require("./Navegador");
const cheerio = require('cheerio');

let precios=""

async function ObtenerPreciosMercado() {
    try {
        const browser = await Navegador();
        const page = await browser.newPage();

        await page.goto('https://www.bybit.com/pt-BR/trade/spot/USDT/BRZ', { waitUntil: 'domcontentloaded' });
        await page.waitForTimeout(20000);

        while (true) {
            try {
                // Obtener el contenido HTML de la página
                const html = await page.content();
                
                // Cargar el HTML en Cheerio
                const $ = cheerio.load(html);
                
                // Seleccionar los elementos que contienen los precios
                const listItems = $('p.price.spot-theme-text-t1');
                
                
                // Extraer los precios de los elementos seleccionados
                if (listItems.length >= 2) {
                  // Almacenar el primer precio con la clave 'compra'
                 const compra = $(listItems[0]).text();
                  // Almacenar el segundo precio con la clave 'venta'
                  const venta = $(listItems[1]).text();
                  
              
                  const data={
                    compra:compra,
                    venta:venta,

                  }

                  precios= data;

                  
              }
                
                // Guardar los precios en el objeto global `precios`

                // Esperar 10 segundos antes de volver a extraer los precios
                await new Promise(resolve => setTimeout(resolve, 10000));


            } catch (error) {
                console.error("Error while scraping:", error);
                // Esperar 3 segundos antes de intentar nuevamente
                await new Promise(resolve => setTimeout(resolve, 3000));
            }
        }
    } catch (error) {
        console.error('Error durante la navegación:', error);
        return null;
    }
}

ObtenerPreciosMercado()

const Prices=async()=>{
  return precios
}
// Ejecutar la función

module.exports={
  ObtenerPreciosMercado,
  Prices

}
