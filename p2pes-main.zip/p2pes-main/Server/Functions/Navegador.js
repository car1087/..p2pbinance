const puppeteer = require('puppeteer-extra');
const StealthPlugin = require('puppeteer-extra-plugin-stealth');
puppeteer.use(StealthPlugin());

let browser;

const Navegador = async () => {
    if (!browser) {
        console.log("Iniciando navegador");
        browser = await puppeteer.launch({
            headless:"new", // Cambia a true para ejecución sin cabeza
            
        });
    } else {
        console.log("Agregando a navegador existente");
    }
    return browser;
};

module.exports = Navegador;
