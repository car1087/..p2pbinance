


const { RestClientV5 } = require('bybit-api');

const dotenv = require('dotenv');
dotenv.config();
const apiKey = process.env.API_KEY;
const secret = process.env.SECRET;


const client = new RestClientV5({
  key: apiKey,
  secret: secret,
});


async function crearOrdenSpotLimit(symbol, side, qty, price) {
    try {
      const response = await client.submitOrder({
        category: 'spot',
        symbol: symbol,
        side: side,
        orderType: 'Limit', // Cambiado a 'Limit'
        qty: qty.toString(),
        price: price.toString(), // Agregar el precio para la orden de límite
      });
  
      console.log(response);
    } catch (error) {
      console.error(error);
    }
}

// const test =async()=>{
//   await crearOrdenSpotLimit("USDTBRZ","Buy",parseFloat(38.38),((5.309)))

// }

// test()


module.exports=crearOrdenSpotLimit