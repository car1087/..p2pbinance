
const { RestClientV5 } = require('bybit-api');

const dotenv = require('dotenv');
dotenv.config();
const apiKey = process.env.API_KEY;
const secret = process.env.SECRET;


const client = new RestClientV5({
  key: apiKey,
  secret: secret,
});



async function crearOrdenSpot(symbol, side, qty) {
    try {
      const response = await client.submitOrder({
        category: 'spot',
        symbol: symbol,
        side: side,
        orderType: 'Market',
        qty: qty.toString(),
      });
  
      console.log(response);
    } catch (error) {
      console.error(error);
    }
  }
  


  module.exports = crearOrdenSpot