

const GetPrecioDeAnuncioOptimoVenta = async (CompraMercado, P2PLIST, NombreUsuarioP2P) => {
    try {
        if (!P2PLIST[0] && !P2PLIST[1]) return false;

        P2PLIST.sort((a, b) => parseFloat(b.precio) - parseFloat(a.precio));

        const PrimeroEnLista = P2PLIST[0];
        const SegundoEnLista = P2PLIST[1];

        const CompraMercadoFloat = parseFloat(CompraMercado);
        const PrimeroEnListaPrice = parseFloat(PrimeroEnLista?.precio);
        const SegundoEnListaPrice = parseFloat(SegundoEnLista?.precio);

        if (PrimeroEnLista && PrimeroEnLista.user !== NombreUsuarioP2P) {
            if (PrimeroEnListaPrice < CompraMercadoFloat - 0.007) {
                return PrimeroEnLista.percent === 100 ? PrimeroEnListaPrice + 0.001 : PrimeroEnListaPrice;
            }
        }

        if (SegundoEnLista && PrimeroEnLista) {
            if (SegundoEnLista.user !== NombreUsuarioP2P && PrimeroEnLista.user === NombreUsuarioP2P) {
                if (SegundoEnListaPrice - PrimeroEnListaPrice > -0.001 && PrimeroEnListaPrice <= (CompraMercadoFloat - 0.007)) {
                    return SegundoEnLista.percent === 100 ? SegundoEnListaPrice + 0.001 : SegundoEnListaPrice;
                }
            }
        }

        if (PrimeroEnLista && PrimeroEnListaPrice > CompraMercadoFloat - 0.009) {
            return CompraMercadoFloat - 0.007;
        }

        if (PrimeroEnListaPrice === SegundoEnListaPrice && PrimeroEnListaPrice <= CompraMercadoFloat - 0.009 && PrimeroEnLista.user !== NombreUsuarioP2P) {
            return SegundoEnListaPrice + 0.001;
        }

        if (PrimeroEnLista.user === NombreUsuarioP2P && SegundoEnListaPrice - PrimeroEnListaPrice > -0.001 && PrimeroEnListaPrice <= (CompraMercadoFloat - 0.007)) {
            return PrimeroEnLista.precio;
        }

        return PrimeroEnLista.precio;
    } catch (error) {
        console.error('Error en GetPrecioDeAnuncioOptimoVenta:', error);
        return null;
    }
}

module.exports = GetPrecioDeAnuncioOptimoVenta;
