const fs = require('fs');
const path = require('path');

function actualizarModo() {
    if (!modo || (modo !== 'venta' && modo !== 'compra')) {
        throw new Error('Modo no válido. Debe ser "venta" o "compra".');
    }

    const modeFilePath = path.join(__dirname, 'mode.json');

    // Lee el contenido actual del archivo mode.json
    fs.readFile(modeFilePath, (err, data) => {
        if (err) {
            throw new Error('Error al leer el archivo mode.json.');
        }

        let modeData = { mode: modo };
        // Si el archivo ya existe, actualiza el modo
        if (data) {
            modeData = JSON.parse(data);
            modeData.mode = modo;
        }

        // Escribe el nuevo modo en el archivo mode.json
        fs.writeFile(modeFilePath, JSON.stringify(modeData), (err) => {
            if (err) {
                throw new Error('Error al actualizar el modo en el archivo mode.json.');
            }
            console.log('Modo actualizado correctamente:', modo);
        });
    });
}

module.exports = {
    actualizarModo
};
