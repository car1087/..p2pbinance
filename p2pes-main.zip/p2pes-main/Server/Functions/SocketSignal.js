const GetData = require("../Main")


let data
let oldData
const w = (ms) => new Promise(resolve => setTimeout(resolve, ms));


const actualizardatos=async()=>{
    while(true) {
    await w(500)
    const response = await GetData()
    if (response){
        data=response
    }
}}

actualizardatos()




const sendData = async (wss) => {
    const sendData2 = async () => {
        if (oldData !== data) {
            const response= {
                name: "p2pestdata",
                data
            };
  
            wss.clients.forEach(client => {
                client.send(JSON.stringify(response));
            });
  
            oldData = data;
        }
    };
  
    // Envía datos cada segundo
     setInterval(sendData2, 1000);
  
    // Limpia el intervalo cuando se cierra la conexión
  }

module.exports={sendData,actualizardatos}