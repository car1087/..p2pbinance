


async function sendTelegramNotification(message) {
    try {
      const telegramBotToken = '6713009855:AAEe4AdmtTjmOEnyjxTZlMMKCZ_PrdDdulk';
      const chatId= "-1002016104732"
      const apiUrl = `https://api.telegram.org/bot${telegramBotToken}/sendMessage`;
  
      const response = await fetch(apiUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          chat_id: chatId,
          text: message,
        }),
      });
  
      const data = await response.json();
  
      if (!data.ok) {
        console.error('Error al enviar la notificación por Telegram:', data);
      } 
    } catch (error) {
      console.error('Error al enviar la notificación por Telegram:', error);
    }
  }
  


  module.exports=sendTelegramNotification