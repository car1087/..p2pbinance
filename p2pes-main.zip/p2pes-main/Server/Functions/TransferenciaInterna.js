
const crypto = require('crypto');
const axios = require('axios');
const { v4: uuidv4 } = require('uuid');
const url = 'https://api.bybit.com';

const dotenv = require('dotenv');
dotenv.config();
const apiKey = process.env.API_KEY;
const secret = process.env.SECRET;



function getSignature(parameters, secret,timestamp) {
  const recvWindow = 10000;
  return crypto.createHmac('sha256', secret).update(timestamp + apiKey + recvWindow + parameters).digest('hex');
}

async function http_request_v5(endpoint, method, data, info) {
const timestamp = Date.now().toString();
  const sign = getSignature(data, secret,timestamp);
  const fullEndpoint = `${url}/v5${endpoint}`;

  const config = {
    method: method,
    url: fullEndpoint,
    headers: {
      'X-BAPI-API-KEY': apiKey,
      'X-BAPI-TIMESTAMP': timestamp,
      'X-BAPI-RECV-WINDOW': '10000',
      'X-BAPI-SIGN': sign,
      'Content-Type': 'application/json; charset=utf-8'

    },
    data: data
  };

  console.log(`${info} Calling...`);
  try {
    const response = await axios(config);
    console.log(JSON.stringify(response.data));
  } catch (error) {
    console.log(error);
  }
}

// Función para realizar una transferencia interna según la API v5
async function transferInternalV5(coin,amount,from,to) {
  const transferId = uuidv4();
  const data = {
    transferId: transferId,
    coin: coin.toString(),
    amount: amount.toString(),
    fromAccountType: from.toString(),
    toAccountType: to.toString()
  };

  const dataString = JSON.stringify(data);

  const endpoint = '/asset/transfer/inter-transfer';
  const method = 'POST';

  await http_request_v5(endpoint, method, dataString, 'Internal Transfer V5');
}


module.exports = transferInternalV5