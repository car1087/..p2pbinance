const { server } = require("./Server");

const PORT = 4030


        server.listen(PORT,"0.0.0.0",() => {
            console.log(`Server listening on port ${PORT}`);
            });
      