const {obtenerBalance,Prices,List,}=require("./Functions/index");
const transferInternalV5 = require("./Functions/TransferenciaInterna")
const crearOrdenSpot = require("./Functions/PostMarketOrder")
const sendTelegramNotification = require("./Functions/Telegram")
const GetPrecioDeAnuncioOptimo= require("./Functions/PrecioOptimo")
const GetPrecioDeAnuncioOptimoVenta=require("./Functions/PrecioOptimoVenta")
const notifier = require('node-notifier');
const copiarNumeroPrecio= require("./Functions/CopyPrice")
const {leerModo} = require("./Functions/GetMode")
const crearOrdenSpotLimit=require("./Functions/PostLimitOrder")


const dotenv = require('dotenv');
dotenv.config();
const comision = process.env.COMISION;
const NOMBRE_DE_USUARIO_P2P= process.env.NOMBRE_DE_USUARIO_P2P


const w = (ms) => new Promise(resolve => setTimeout(resolve, ms));

const monedas = ['USDT', 'BRZ', 'BRL'];

let Precios
let Lista
let FundBalances 
let SpotBalances
let BalanceActual
let Cargando
let BalanceInicial
let ganancias=0
let GananciaPorVentaTotal=0
let PrecioSugerido
let AccionRequerida
let AccionActual
let priceNotified



let DataToResponse




const MainBucle=async()=>{
    try{
    while(true){
        const setmode=await leerModo()
  
        if(setmode==="compra"){
            console.log("modo-compra")

        AccionActual="Esperando"
        AccionRequerida="Esperando"

        FundBalances= await obtenerBalance('FUND', monedas);
        SpotBalances= await obtenerBalance('UNIFIED', monedas);
        Precios=await Prices()
        Lista=await List()

        if (!FundBalances || !SpotBalances || !Lista || !Precios ||!Lista.lenght > 1) {
            Cargando=true
        }else{
            Cargando=false   }


        if(Cargando){

            DataToResponse={
                Charging:Cargando}
                console.clear()

            console.log(DataToResponse)
        }


        if(!Cargando){


            let oldPrecioOptimo



            if (FundBalances.BRZ >=50){
                AccionActual="Transfiriendo BRZ a Spot"

                await transferInternalV5("BRZ",FundBalances.BRZ,"FUND","UNIFIED")
                await new Promise((resolve) => setTimeout(resolve, 1000));
                SpotBalances= await obtenerBalance('UNIFIED', monedas);

                await new Promise((resolve) => setTimeout(resolve, 1000))
              }

            
              if(SpotBalances.BRZ>=50 ){

                AccionActual="Comprando USDT por BRZ "
               
                if (Lista) {
                    let usuarioEncontrado = null;
                
                    Lista.forEach(objeto => {
                        if (objeto.user === NOMBRE_DE_USUARIO_P2P) {
                            usuarioEncontrado = objeto;
                            return; // Salir del bucle forEach una vez que se encuentra el usuario
                        }
                    });
                
                    if (setmode === "compra" && usuarioEncontrado && usuarioEncontrado.precio <= ((Precios.compra) + 0.009)) {
                        const fixedprice = (parseFloat(usuarioEncontrado.precio) - 0.006);
                        const usdtorder = (parseFloat(SpotBalances.BRZ) / (parseFloat(usuarioEncontrado.precio) - 0.006)).toFixed(2);
                
                        await crearOrdenSpotLimit("USDTBRZ", "Buy", usdtorder, fixedprice);
                    } else if (setmode === "venta" && usuarioEncontrado && usuarioEncontrado.precio >= parseFloat((Precios.venta) - 0.009)) {
                        const fixedprice = (parseFloat(usuarioEncontrado.precio) + 0.006);
                        const usdtorder = (parseFloat(SpotBalances.BRZ) / (parseFloat(usuarioEncontrado.precio) + 0.006)).toFixed(2);
                
                        await crearOrdenSpotLimit("USDTBRZ", "Sell", usdtorder, fixedprice);
                    } else {
                        // Si no se cumplen las condiciones del usuario y el precio, hacer una orden de tipo "market"
                        await crearOrdenSpot("USDTBRZ", "Buy", parseFloat(SpotBalances.BRZ));
                    }
                
                    // Esperar un segundo antes de obtener el balance
                    await new Promise((resolve) => setTimeout(resolve, 1000));  
                    SpotBalances = await obtenerBalance('UNIFIED', monedas);
                    // Esperar otro segundo antes de continuar
                    await new Promise((resolve) => setTimeout(resolve, 1000));
                }
                

              }



              
            if(SpotBalances.USDT>=10){
                AccionActual="Transfiriendo USDT a Fund"
                await transferInternalV5("USDT",SpotBalances.USDT,"UNIFIED","FUND")
                notifier.notify({
                title: 'TRANSFIERE Y ACTUALIZA TU ANUNCIO ',
                message: "HAY USD PARA AGREGAR A TU ANUNCIO ",
                });
            
                await sendTelegramNotification("TRANSFIERE Y ACTUALIZA TU ANUNCIO '"); 
                AccionRequerida="ACTUALIZA TU ANUNCIO"

            }



            if (parseFloat(FundBalances.BRL) > 50){
                AccionActual="Esperando.."
                notifier.notify({
                  title: 'Transforma tu BRL a BRZ',
                  message:`Transforma tu BRL a BRZ: ${FundBalances.BRL}`,
                });
            
                await sendTelegramNotification(`Transforma tu BRL a BRZ: ${FundBalances.BRL}`);
                AccionRequerida="Transforma tu BRL a BRZ"

              }
              const usdtbalancefund = FundBalances && FundBalances.USDT || 0;
              const usdtbalancespot = SpotBalances && SpotBalances.USDT || 0;
              const brzbalancespot = SpotBalances && SpotBalances.BRZ || 0;
              const brlbalancefund = FundBalances && FundBalances.BRL || 0;
              const brzbalancefund = FundBalances && FundBalances.BRZ || 0;
              

              const USDTBALANCE= parseFloat(usdtbalancefund+usdtbalancespot)
              const BRLBALANCE= parseFloat(brzbalancespot+brlbalancefund+brzbalancefund)

            const precioBRZ = parseFloat(Precios.compra)
            if (!BalanceInicial){
                BalanceInicial = parseFloat(USDTBALANCE + (BRLBALANCE / precioBRZ)).toFixed(2)
            }

             BalanceActual =parseFloat(USDTBALANCE + (BRLBALANCE / precioBRZ)).toFixed(2)

            if(BalanceActual !== BalanceInicial) {
            
             const NuevoBalance =BalanceActual

              ganancias = (parseFloat(NuevoBalance)-parseFloat(BalanceInicial)).toFixed(2);}

                    const comisionDecimal= comision / 100; 
        
                    const gananciaBruta = ((USDTBALANCE * PrecioSugerido) / precioBRZ) - USDTBALANCE;
                    const comisionTotal = gananciaBruta * comisionDecimal;
                    const gananciaNeta = gananciaBruta - comisionTotal;
                    
                    GananciaPorVentaTotal = gananciaNeta


            const MercadoCompra=Precios.compra
            const presponse=await GetPrecioDeAnuncioOptimo(MercadoCompra, Lista,NOMBRE_DE_USUARIO_P2P )

                 PrecioSugerido=parseFloat(presponse).toFixed(3)

                 if (isNaN(PrecioSugerido)&&Lista&&Lista[0] &&Lista[0].precio ) {
                    const myadd=Lista[0].precio;
                    if(myadd){
                    PrecioSugerido = Lista[0].precio;}
                    if(!myadd){PrecioSugerido=0}
                }
                

                if (PrecioSugerido !== oldPrecioOptimo &&PrecioSugerido>0) {
                    // Si PrecioSugerido es diferente a oldPrecioOptimo y no es NaN
                    oldPrecioOptimo = PrecioSugerido;



                    if(priceNotified!==PrecioSugerido){
                    await copiarNumeroPrecio(PrecioSugerido)

                    notifier.notify({
                        title: 'Actualiza tu Precio-Copied',
                        message: `Actualiza tu Precio a: ${PrecioSugerido}`,
                      });
                    
                      priceNotified=PrecioSugerido

                    }

                    await sendTelegramNotification(`Actualiza tu Precio a: ${PrecioSugerido}`);
                  
                    AccionRequerida = `Actualiza tu Precio a: ${PrecioSugerido}`;


                


                }
                
     

                
                DataToResponse={
                    Charging:Cargando,
                    Lista,
                    Precios,
                    PrecioSugerido,
                    FundBalances,
                    SpotBalances,
                    BalanceActual,
                    AccionActual,
                    AccionRequerida,
                    ganancias,
                    GananciaPorVentaTotal,
                    NOMBRE_DE_USUARIO_P2P,
            }
        

            console.clear()
            console.log(">>>Cargado<<<")

            if(!DataToResponse.Charging)console.log("Abre en tu Navegador http://localhost:5173/ en tu navegador")

      

    

            }
        
        }


        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

        if(setmode==="venta"){

            console.log("modo-venta")
            AccionActual="Esperando"
            AccionRequerida="Esperando"
    
            FundBalances= await obtenerBalance('FUND', monedas);
            SpotBalances= await obtenerBalance('UNIFIED', monedas);
            Precios=await Prices()
            Lista=await List()
    
            if (!FundBalances || !SpotBalances || !Lista || !Precios ||!Lista.lenght > 1) {
                Cargando=true
            }else{
                Cargando=false   }
    
    
            if(Cargando){
    
                DataToResponse={
                    Charging:Cargando}
                    console.clear()
    
                console.log(DataToResponse)
            }
    
    
            if(!Cargando){
    
    
                let oldPrecioOptimo
    
    
    
                if (FundBalances.USDT >=10){
                    AccionActual="Transfiriendo USDT  a Spot"

                    await transferInternalV5("USDT",FundBalances.USDT,"FUND","UNIFIED")
                    await new Promise((resolve) => setTimeout(resolve, 1000));
                    SpotBalances= await obtenerBalance('UNIFIED', monedas);
    
                    await new Promise((resolve) => setTimeout(resolve, 1000))
                  }
    
                
                  if(SpotBalances.USDT>=10 ){
                    
                    AccionActual="Comprando BRZ por USDT "
                    const fixedusdt=(SpotBalances.USDT).toFixed(1)
                    await crearOrdenSpot("USDTBRZ","Sell",parseFloat(fixedusdt))
                   await new Promise((resolve) => setTimeout(resolve, 1000));
                   SpotBalances= await obtenerBalance('UNIFIED', monedas);
                   await new Promise((resolve) => setTimeout(resolve, 1000));
                    
                  }
    
    
    
                  
                if(SpotBalances.BRZ>=50){
                    AccionActual="Transfiriendo BRZ a Fund"
                    await transferInternalV5("BRZ",SpotBalances.BRZ,"UNIFIED","FUND")
                    notifier.notify({
                    title: 'TRANSFORMA TU BRZ A BRL  Y ACTUALIZA TU ANUNCIO ',
                    message: "HAY BRZ PARA TRANSFORMAR EN BRL Y  AGREGAR A TU ANUNCIO ",
                    });
                
                    await sendTelegramNotification("TRANSFORMA TU BRZ A BRL  Y ACTUALIZA TU ANUNCIO"); 
                    AccionRequerida="HAY BRZ PARA TRANSFORMAR EN BRL Y  AGREGAR A TU ANUNCIO"
    
                }
    
    
    
                if (parseFloat(FundBalances.BRZ) > 50){
                    AccionActual="Esperando.."
                    notifier.notify({
                      title: 'Transforma tu BRZ a BRL Y AGRÉGALO A TU ANUNCIO',
                      message:`Transforma tu BRZ a BRL Y AGRÉGALO A TU ANUNCIO: ${FundBalances.BRZ}`,
                    });
                
                    await sendTelegramNotification(`Transforma tu BRZ a BRL Y AGREGALO : ${FundBalances.BRZ}`);
                    AccionRequerida="Transforma tu BRZ a BRL Y AGREGALO"
    
                  }
    
                  const usdtbalancefund = FundBalances && FundBalances.USDT || 0;
                  const usdtbalancespot = SpotBalances && SpotBalances.USDT || 0;
                  const brzbalancespot = SpotBalances && SpotBalances.BRZ || 0;
                  const brlbalancefund = FundBalances && FundBalances.BRL || 0;
                  const brzbalancefund = FundBalances && FundBalances.BRZ || 0;
                  
                  const USDTBALANCE= parseFloat(usdtbalancefund+usdtbalancespot)
                  const BRLBALANCE= parseFloat(brzbalancespot+brlbalancefund+brzbalancefund)
      
                  const precioBRZ = parseFloat(Precios.compra)
                  if (!BalanceInicial){
                      BalanceInicial = parseFloat(USDTBALANCE + (BRLBALANCE / precioBRZ)).toFixed(2)
                  }
      
                   BalanceActual =parseFloat(USDTBALANCE + (BRLBALANCE / precioBRZ)).toFixed(2)
    
    
                if(BalanceActual !== BalanceInicial) {
                
                 const NuevoBalance =BalanceActual
    
          ganancias = (parseFloat(NuevoBalance)-parseFloat(BalanceInicial)).toFixed(2);}
    
                        const comisionDecimal= comision / 100; 
            
                        const gananciaBruta = ((BRLBALANCE / PrecioSugerido) * precioBRZ) - BRLBALANCE;
                        const comisionTotal = gananciaBruta * comisionDecimal;  
                        const gananciaNeta = gananciaBruta - comisionTotal;
                        
                        GananciaPorVentaTotal = gananciaNeta
    
                const MercadoVenta=Precios.venta
                const presponse=await GetPrecioDeAnuncioOptimoVenta(MercadoVenta, Lista,NOMBRE_DE_USUARIO_P2P )
    
                     PrecioSugerido=parseFloat(presponse).toFixed(3)
    
                     if (isNaN(PrecioSugerido)&&Lista&&Lista[0] &&Lista[0].precio ) {
                        const myadd=Lista[0].precio;
                        if(myadd){
                        PrecioSugerido = Lista[0].precio;}
                        if(!myadd){PrecioSugerido=0}
                    }
                    
    
                    if (PrecioSugerido !== oldPrecioOptimo &&PrecioSugerido>0) {
                        // Si PrecioSugerido es diferente a oldPrecioOptimo y no es NaN
                        oldPrecioOptimo = PrecioSugerido;
    
    
    
                        if(priceNotified!==PrecioSugerido){
                            await copiarNumeroPrecio(PrecioSugerido)

                        notifier.notify({
                            title: 'Actualiza tu Precio-Copied',
                            message: `Actualiza tu Precio a: ${PrecioSugerido}`,
                          });
                        
                          priceNotified=PrecioSugerido
    
                        }
    
                        await sendTelegramNotification(`Actualiza tu Precio a: ${PrecioSugerido}`);
                      
                        AccionRequerida = `Actualiza tu Precio a: ${PrecioSugerido}`;
    
                    
                        
                    }
                    
         
    
                    
                    DataToResponse={
                        Charging:Cargando,
                        Lista,
                        Precios,
                        PrecioSugerido,
                        FundBalances,
                        SpotBalances,
                        BalanceActual,
                        AccionActual,
                        AccionRequerida,
                        ganancias,
                        GananciaPorVentaTotal,
                        NOMBRE_DE_USUARIO_P2P,
                }
            
    
                console.clear()
                console.log(">>>Cargado<<<")
    
                if(!DataToResponse.Charging)console.log("Abre en tu Navegador http://localhost:5173/ en tu navegador")
    
          
    
        
    
            }




            
        }









        await w(3000)



        }



    }catch(e){console.log(e)
    }
}

const Init=async()=>{

   FundBalances= await obtenerBalance('FUND', monedas);
   SpotBalances= await obtenerBalance('UNIFIED', monedas);
   


   Precios=await Prices()
   Lista=await List()

   MainBucle()

}

Init()



const GetData=async()=>{

    if (DataToResponse){

    return DataToResponse
    }
    }




    module.exports = GetData