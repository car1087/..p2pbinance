const { Router } = require("express");

const {actualizarModo} = require("../Functions/ChangeMode")
const {getActualMode}=require("../Functions/GetActualMode")



const routes = Router();


routes.post("/ChangeMode",actualizarModo)
routes.get("/GetMode",getActualMode)

module.exports=routes