const {sendData,actualizardatos} =require("../Functions/SocketSignal")



const sendrespose = async (wss) => {
    wss.on('connection', (ws) => {
        sendData(wss);
    });
};


let test="hole"


const socketroutes= {sendrespose,test}


module.exports= socketroutes

